# UsageAggregator/blob_writer.py
import json
from azure.storage.blob import BlobServiceClient

class BlobWriter:
    def __init__(self, conn_str: str, container: str):
        pass
        # self._svc = BlobServiceClient.from_connection_string(conn_str)
        # self._container = self._svc.get_container_client(container)

    @staticmethod
    def build_blob_path(y: int, m: int, d: int) -> str:
        # YYYY/MM/usage_agg_YYYYMMDD.json
        return f"{y:04d}/{m:02d}/usage_agg_{y:04d}{m:02d}{d:02d}.json"

    def upload_json(self, blob_path: str, payload: dict) -> None:
        # body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        # self._container.upload_blob(name=blob_path, data=body, overwrite=True)  # バージョニングON前提で上書き
        print("===============Blob Writer===============")
        print(dict)
