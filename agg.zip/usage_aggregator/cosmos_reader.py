# UsageAggregator/cosmos_reader.py
from azure.cosmos import CosmosClient
from typing import Iterator, Dict, Any, Optional, Tuple

class CosmosReader:
    def __init__(self, endpoint: str, key: str, db: str, container: str, page_size: int = 1000, verify=True):
        self._client = CosmosClient(endpoint, key, connection_verify=True)
        self._container = self._client.get_database_client(db).get_container_client(container)
        self._page_size = page_size

    def iter_talk_history(self, start_epoch: int, end_epoch: int) -> Iterator[Dict[str, Any]]:
        query = "SELECT * FROM c WHERE c._ts >= @s AND c._ts < @e"
        params = [{"name":"@s","value":start_epoch},
                  {"name":"@e","value":end_epoch}]

        for doc in self._container.query_items(
            query=query, parameters=params,
            enable_cross_partition_query=True,
            max_item_count=self._page_size
        ):
            yield doc

    def count_in_window(self, start_epoch: int, end_epoch: int) -> int:
        query = "SELECT VALUE COUNT(1) FROM c WHERE c._ts >= @s AND c._ts < @e"
        params = [{"name":"@s","value":start_epoch},
                  {"name":"@e","value":end_epoch}]
        it = self._container.query_items(query=query, parameters=params, enable_cross_partition_query=True)
        for v in it:
            return int(v)
        return 0

    def min_ts(self) -> int | None:
        q = "SELECT VALUE MIN(c._ts) FROM c"
        it = self._container.query_items(q, enable_cross_partition_query=True)
        for v in it:  # 1行だけ来る
            return int(v) if v is not None else None
        return None
    
    def max_ts(self) -> int | None:
        q = "SELECT VALUE MAX(c._ts) FROM c"
        it = self._container.query_items(q, enable_cross_partition_query=True)
        for v in it:
            return int(v) if v is not None else None
        return None


