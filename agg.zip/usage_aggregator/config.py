from dataclasses import dataclass
import os
import datetime
import logging

JST = datetime.timezone(datetime.timedelta(hours=9), name="JST")


def _to_epoch_seconds_utc(dt: datetime.datetime) -> int:
    """タイムゾーンありのdatetimeをUTCのエポック秒へ変換する"""
    if dt.tzinfo is None:
        # タイムゾーン情報がなかったらエラーに倒す
        raise ValueError("datetime must be timezone-aware")
    return int(dt.astimezone(datetime.timezone.utc).timestamp())

@dataclass(frozen=True)
class Config:
    cosmos_endpoint: str
    cosmos_key: str
    cosmos_db: str
    cosmos_container: str
    blob_conn_str: str
    blob_container: str
    page_size: int
    max_duration_sec: int
    target_date: str | None = None

    @classmethod
    def from_env(cls) -> "Config":
        return cls(
            cosmos_endpoint = os.environ["COSMOSDB_ENDPOINT"],
            cosmos_key= os.environ["COSMOSDB_KEY"],
            cosmos_db= os.environ["COSMOSDB_DB"],
            cosmos_container= os.environ["COSMOSDB_CONTAINER"],
            blob_conn_str= os.environ["BLOB_CONN_STR"],
            blob_container= os.environ["BLOB_CONTAINER"],
            page_size= int(os.getenv("PAGE_SIZE", "4000")),
            max_duration_sec= int(os.getenv("MAX_DURATION_SEC", "7200")),
            target_date= os.getenv("TARGET_DATE")
        )

    # —— JSTに合わせた集計ウィンドウ（TimeWindow統合） —— #
    def resolve_window(self):
        """
        戻り値(dict):
          'target_date'        : date(JST基準の対象日：昨日 or TARGET_DATE)
          'window_start_jst'   : datetime(JST 00:00:00)
          'window_end_jst'     : datetime(JST 24:00:00 = 翌日00:00)
          'start_epoch_utc'    : int(UTC epoch seconds, 10桁)
          'end_epoch_utc'      : int(UTC epoch seconds, 10桁)
          'window_start_utc_dt': datetime(可読; UTC)
          'window_end_utc_dt'  : datetime(可読; UTC)
        """
        # TARGET_DATE の形式チェック（YYYYMMDD）
        if self.target_date:
            s = self.target_date.strip()
            if len(s) != 8 or not s.isdigit():
                raise ValueError(f"TARGET_DATE must be YYYYMMDD, got: {self.target_date!r}")
            d = datetime.datetime.strptime(s, "%Y%m%d").date()
        else:
            now_jst = datetime.datetime.now(JST)
            d = (now_jst - datetime.timedelta(days=1)).date()

        # JST 00:00〜24:00 を決定
        ws_jst = datetime.datetime(d.year, d.month, d.day, 0, 0, 0, tzinfo=JST)
        we_jst = ws_jst + datetime.timedelta(days=1)

        # UTC epoch seconds（10桁）へ変換
        start_epoch = _to_epoch_seconds_utc(ws_jst)
        end_epoch = _to_epoch_seconds_utc(we_jst)

        # 可読なUTC時刻（デバッグ・運用ログ用）
        ws_utc = ws_jst.astimezone(datetime.timezone.utc)
        we_utc = we_jst.astimezone(datetime.timezone.utc)

        logging.info("=== aggregation window ===")
        logging.info({
            "target_date": d.isoformat(),
            "window_start_jst": ws_jst.isoformat(),
            "window_end_jst": we_jst.isoformat(),
            "window_start_utc": ws_utc.isoformat(),
            "window_end_utc": we_utc.isoformat(),
            "start_epoch": start_epoch,
            "end_epoch": end_epoch
        })

        return {
            "target_date": d,
            "window_start_jst": ws_jst,
            "window_end_jst": we_jst,
            "start_epoch_utc": start_epoch,
            "end_epoch_utc": end_epoch,
            "window_start_utc_dt": ws_utc,
            "window_end_utc_dt": we_utc
        }
