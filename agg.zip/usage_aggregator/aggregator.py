# UsageAggregator/aggregator.py
from dataclasses import dataclass, asdict
from typing import List


@dataclass
class Metrics:
    talknum_total: int = 0
    record_count: int = 0
    good_total: int = 0
    bad_total: int = 0


class Aggregator:
    """
    逐次加算する集計器。
    bad_talk_paths は要件通り「重複排除なし」で連結。
    """

    def __init__(self):
        self.metrics = Metrics()
        self.bad_paths: List[str] = []

    def aggregate_doc(self, doc: dict) -> None:
        self.metrics.record_count += 1
        self.metrics.talknum_total += int(doc.get("talknum", 0))
        for it in (doc.get("items") or []):
            self.metrics.good_total += int(it.get("good", 0))
            self.metrics.bad_total += int(it.get("bad", 0))
            paths = it.get("bad_talk_path") or []
            if isinstance(paths, list):
                for p in paths:
                    if isinstance(p, str):
                        self.bad_paths.append(p)

    def to_payload(self, window_start: str, window_end: str, generated_at: str) -> dict:
        return {
            "window_start": window_start,
            "window_end":   window_end,
            "generated_at": generated_at,
            "metrics": asdict(self.metrics),
            "bad_talk_paths": self.bad_paths,
        }
