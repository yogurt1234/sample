# tests/test_config.py
import datetime as dt
import os
import types
import pytest

from usage_aggregator.config import Config, _to_epoch_seconds_utc, JST


# -----------------------------
# Fixtures / Helpers
# -----------------------------
@pytest.fixture
def env_required(monkeypatch):
    """from_env が要求する必須ENVをセット(デフォルト値も含む)"""
    monkeypatch.setenv("COSMOSDB_ENDPOINT", "https://example.documents.azure.com:443/")
    monkeypatch.setenv("COSMOSDB_KEY", "fake-key")
    monkeypatch.setenv("COSMOSDB_DB", "db")
    monkeypatch.setenv("COSMOSDB_CONTAINER", "container")
    monkeypatch.setenv("BLOB_CONN_STR", "DefaultEndpointsProtocol=https;AccountName=acc;AccountKey=key;")
    monkeypatch.setenv("BLOB_CONTAINER", "usage")
    # 省略時の既定値の動作も見るので PAGE_SIZE/MAX_DURATION_SEC/TARGET_DATE はここでは未設定


# -----------------------------
# _to_epoch_seconds_utc
# -----------------------------
def test_to_epoch_seconds_utc_ok():
    """JSTのdatetimeを正しくepochに変換できること"""
    aware = dt.datetime(2025, 9, 15, 12, 0, 0, tzinfo=JST)
    got = _to_epoch_seconds_utc(aware)
    # 再計算して一致を確認
    assert got == int(aware.timestamp())


def test_to_epoch_seconds_utc_naive_raises():
    """"datetimeにタイムゾーンの指定がない場合に例外が発生すること"""
    naive = dt.datetime(2025, 9, 15, 12, 0, 0)
    with pytest.raises(ValueError):
        _to_epoch_seconds_utc(naive)


# -----------------------------
# Config.from_env
# -----------------------------
def test_from_env_reads_required_and_defaults(env_required):
    cfg = Config.from_env()
    assert cfg.cosmos_endpoint.startswith("https://")
    assert cfg.cosmos_key == "fake-key"
    assert cfg.cosmos_db == "db"
    assert cfg.cosmos_container == "container"
    assert cfg.blob_container == "usage"
    # 既定値
    assert cfg.page_size == 4000
    assert cfg.max_duration_sec == 7200
    assert cfg.target_date is None


def test_from_env_with_overrides(env_required, monkeypatch):
    monkeypatch.setenv("PAGE_SIZE", "123")
    monkeypatch.setenv("MAX_DURATION_SEC", "4567")
    monkeypatch.setenv("TARGET_DATE", "20250914")

    cfg = Config.from_env()
    assert cfg.page_size == 123
    assert cfg.max_duration_sec == 4567
    assert cfg.target_date == "20250914"


# -----------------------------
# resolve_window
# -----------------------------
def test_resolve_window_with_target_date(env_required, monkeypatch):
    # TARGET_DATE 指定時はその日（JST基準）の 00:00〜24:00
    monkeypatch.setenv("TARGET_DATE", "20250914")
    cfg = Config.from_env()

    tw = cfg.resolve_window()
    # target_date
    assert tw["target_date"].isoformat() == "2025-09-14"

    # JST 00:00〜24:00
    ws_jst = dt.datetime(2025, 9, 14, 0, 0, 0, tzinfo=JST)
    we_jst = ws_jst + dt.timedelta(days=1)
    assert tw["window_start_jst"] == ws_jst
    assert tw["window_end_jst"] == we_jst

    # UTC 表現
    assert tw["window_start_utc_dt"] == ws_jst.astimezone(dt.timezone.utc)
    assert tw["window_end_utc_dt"] == we_jst.astimezone(dt.timezone.utc)

    # epoch はUTC基準
    assert tw["start_epoch_utc"] == int(ws_jst.astimezone(dt.timezone.utc).timestamp())
    assert tw["end_epoch_utc"] == int(we_jst.astimezone(dt.timezone.utc).timestamp())


def test_resolve_window_without_target_date_uses_yesterday_jst(env_required, monkeypatch):
    # datetime.now(JST) を固定して、「前日」が使われることを検証
    fixed_now_jst = dt.datetime(2025, 9, 15, 10, 30, 0, tzinfo=JST)  # 任意の時刻（JST）

    # config モジュール内の datetime を部分モック： datetime.now(JST) が fixed を返すようにする
    import usage_aggregator.config as config_mod

    class _FixedDateTime(dt.datetime):
        @classmethod
        def now(cls, tz=None):
            if tz is None:
                # naiveを返さないように注意（本実装は tz 指定で呼ぶ）
                return fixed_now_jst.astimezone(dt.timezone.utc).replace(tzinfo=None)
            return fixed_now_jst.astimezone(tz)

    monkeypatch.setattr(config_mod, "datetime", types.SimpleNamespace(
        datetime=_FixedDateTime,
        timedelta=dt.timedelta,
        timezone=dt.timezone,
    ))

    cfg = Config.from_env()
    tw = cfg.resolve_window()

    # 期待される target_date は JST の「前日」= 2025-09-14
    assert tw["target_date"].isoformat() == "2025-09-14"

    # JST 00:00〜24:00 の境界検証
    ws_jst = dt.datetime(2025, 9, 14, 0, 0, 0, tzinfo=JST)
    we_jst = ws_jst + dt.timedelta(days=1)
    assert tw["window_start_jst"] == ws_jst
    assert tw["window_end_jst"] == we_jst

    # epoch も一致
    assert tw["start_epoch_utc"] == int(ws_jst.astimezone(dt.timezone.utc).timestamp())
    assert tw["end_epoch_utc"] == int(we_jst.astimezone(dt.timezone.utc).timestamp())


def test_resolve_window_invalid_target_date_raises(env_required, monkeypatch):
    # 桁数・数値形式の検証
    monkeypatch.setenv("TARGET_DATE", "2025-09-14")  # 不正形式
    cfg = Config.from_env()
    with pytest.raises(ValueError):
        cfg.resolve_window()
