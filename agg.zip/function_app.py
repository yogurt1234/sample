from dataclasses import dataclass
import time
import logging
import datetime
from typing import Any, Dict
import azure.functions as func

from usage_aggregator.config import Config, JST
from usage_aggregator.cosmos_reader import CosmosReader
from usage_aggregator.aggregator import Aggregator
from usage_aggregator.blob_writer import BlobWriter

app = func.FunctionApp()
log = logging.getLogger("usage-agg")


@dataclass(frozen=True)
class Ctx:
    """設定値や状態を保持する"""
    cfg: Config
    tw: Dict[str, Any]
    agg: Aggregator
    reader: CosmosReader
    writer: BlobWriter
    start_time: float

def _init_context() -> Ctx:
    """コンテキストの初期化"""
    log.info("=== Context initialization started ===")

    start_time = time.time()                    # 実行時間計測開始（秒）
    cfg = Config.from_env()              # 環境変数から各種接続情報・設定値を読込
    tw = cfg.resolve_window()           # 集計対象の時間窓（JST/UTC双方の境界や対象日など）を算出
    agg = Aggregator()                   # 集計ロジックインスタンス
    csms_reader = CosmosReader(                  # Cosmos DB 読み取り用ラッパークラス
        cfg.cosmos_endpoint,
        cfg.cosmos_key,
        cfg.cosmos_db,
        cfg.cosmos_container,
        page_size=cfg.page_size
    )
    storacct_writer = BlobWriter(                # Blob Storage 書き込み用ラッパークラス
        cfg.blob_conn_str,
        cfg.blob_container
    )

    # ===== 実行パラメータのログ出力 =====
    log.info({
        "cosmos_endpoint": cfg.cosmos_endpoint,
        "cosmos_db": cfg.cosmos_db,
        "cosmos_container": cfg.cosmos_container,
        "blob_container": cfg.blob_container,
        "page_size": cfg.page_size,
        "max_duration_sec": cfg.max_duration_sec,
        "target_date(env)": cfg.target_date,
        "target_date": tw["target_date"].isoformat(),
        "window_start_jst": tw["window_start_jst"].isoformat(),
        "window_end_jst": tw["window_end_jst"].isoformat(),
        "window_start_utc_dt": tw["window_start_utc_dt"].isoformat(),
        "window_end_utc_dt": tw["window_end_utc_dt"].isoformat(),
        "start_epoch_utc": tw["start_epoch_utc"],
        "end_epoch_utc": tw["end_epoch_utc"]
    })

    ctx = Ctx(
        cfg=cfg,
        tw=tw,
        agg=agg,
        reader=csms_reader,
        writer=storacct_writer,
        start_time=start_time
    )
    log.info("=== Context initialization completed ===")
    return ctx

def _process_usage_aggregation(ctx: Ctx, progress_interval: int = 1000) -> Dict[str, Any]:
    """
    Cosmos から指定ウィンドウのデータを読み出して集計し、Blob へ出力する。
    返り値には、監視やテストで使えるメタ情報を返す。
    """
    # 進捗のカウンタ変数
    processed = 0
    # ===== データ読み取り～集計 =====
    for doc in ctx.reader.iter_talk_history(ctx.tw["start_epoch_utc"], ctx.tw["end_epoch_utc"]):
        try:
            ctx.agg.aggregate_doc(doc)
            processed += 1

            if progress_interval and processed % progress_interval == 0:
                log.info(f"processed={processed}")
        except Exception:
            # レコード単位の解析エラーはスキップ（集計処理は継続する）
            log.error("record parse error", exc_info=True)

    # ===== ペイロード構築 =====
    now_jst = datetime.datetime.now(JST)
    payload = ctx.agg.to_payload(
        window_start=ctx.tw["window_start_jst"].strftime("%Y%m%d_%H%M%S"),
        window_end=ctx.tw["window_end_jst"].strftime("%Y%m%d_%H%M%S"),
        generated_at=now_jst.strftime("%Y%m%d_%H%M%S"),
    )
    return payload


def _write_to_blob(ctx: Ctx, payload: dict) -> str:
    """集計結果を Blob に JSON として保存し、保存先パスを返す"""
    td = ctx.tw["target_date"]
    blob_path = ctx.writer.build_blob_path(td.year, td.month, td.day)
    ctx.writer.upload_json(blob_path, payload)
    log.info(f"uploaded payload to {blob_path}")
    return blob_path


def _check_duration(ctx: Ctx) -> None:
    """所要時間を測定してログ出力し、閾値超過時には警告を出す"""
    elapsed_time = time.time() - ctx.start_time
    log.info(f"elapsed_time:{elapsed_time} check completed")
    if elapsed_time > ctx.cfg.max_duration_sec:
        log.warning(
            f"duration_threshold_exceeded: {elapsed_time:.1f}s > {ctx.cfg.max_duration_sec}s"
        )


# @app.schedule(
#     schedule="0 0 18 * * *",   # UTC 18:00 = JST 翌日 03:00
#     arg_name="timer",
#     run_on_startup=False,
#     use_monitor=True
# )
@app.timer_trigger(schedule="0 * * * * *",
                   arg_name="timer",
                   run_on_startup=True,
                   use_monitor=False)
def usage_aggregator(timer: func.TimerRequest) -> None:
    """
    指定された期間(JST基準)で Cosmos DB の使用ログを集計し、
    集計結果を JSON として Azure Blob Storage にアップロードする。
    実行状況・メトリクスはログに記録する。
    """
    try:
        ctx = _init_context()
        payload = _process_usage_aggregation(ctx)
        _write_to_blob(ctx, payload)
        _check_duration(ctx)

    except Exception:
        # 失敗として検知させる Application Insightsに検知させる
        # 原因特定後、環境プロパティのTARGET_DATEを指定して再実行可能
        log.error("aggregation failed", exc_info=True)
        raise
